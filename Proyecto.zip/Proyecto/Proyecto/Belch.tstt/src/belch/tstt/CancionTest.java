/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package belch.tstt;

import co.com.belch.dao.CancionDao;
import co.com.belch.ent.Cancion;
import co.com.belch.ent.Genero;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ESTEBAN
 */
public class CancionTest {

    private CancionDao canciond;
    private Cancion canciont;
    private Genero gn;

    public boolean crearCancion() throws SQLException {

        canciond = new CancionDao();
        canciont = new Cancion();
        gn = new Genero();

        canciont.setNombreCancion("la pita");
        canciont.setDuracion(123);
        canciont.setletraCancion("todos los caminos conducen a roma");

        gn.setIdGenero(1);
        canciont.setGenero(gn);
        canciont = canciond.crearCancion(canciont);
        if (canciont.getIdCancion() == null) {
            return false;
        } else {
            System.out.println("cancion creada: " + canciont.getNombreCancion());
            System.out.println("duracion cancion: " + canciont.getDuracion());
            System.out.println("letra de cancion: " + canciont.getletraCancion());
            System.out.println("genero: " + canciont.getGenero());
            return true;
        }
    }

    public boolean consultarCancion() throws SQLException {

        canciond = new CancionDao();
        canciont = new Cancion();
        gn = new Genero();

        canciont.setNombreCancion("la pita");
        canciont.setDuracion(123);
        canciont.setletraCancion("todos los caminos conducen a roma");
        gn.setIdGenero(1);
        canciont.setGenero(gn);

        List<Cancion> lCancion = new ArrayList<Cancion>();

        lCancion = canciond.consultar(canciont);
        for (Cancion cTemp : lCancion) {
            System.out.println("Nombre Cancion: " + cTemp.getNombreCancion());
            System.out.println("Duracion Cancion: " + cTemp.getDuracion());
            System.out.println("Letra Cancion: " + cTemp.getletraCancion());
            System.out.println("Genero Cancion: " + cTemp.getGenero());
            System.out.println("---------------------------------------------");
        }

        return true;

    }

    public boolean obtenerTodoCancion() throws SQLException {
        canciond = new CancionDao();
        List<Cancion> lCancion = new ArrayList<Cancion>();

        lCancion = canciond.obtenerTodo();

        for (Cancion cTemp : lCancion) {
            System.out.println("Nombre Todo Cancion: " + cTemp.getNombreCancion());
            System.out.println("------------------------------------------------");
        }
        return true;
    }

    public boolean actualizarCancion() throws SQLException {
        canciond = new CancionDao();
        canciont = new Cancion();
        gn = new Genero();

        canciont.setNombreCancion("la pita");
        canciont.setDuracion(123);
        canciont.setletraCancion("todos los caminos conducen a roma");
        gn.setIdGenero(1);
        canciont.setGenero(gn);

        canciont = canciond.crearCancion(canciont);
        this.obtenerTodoCancion();

        canciont.setNombreCancion("Disvolve");
        canciont.setDuracion(60);
        canciont.setletraCancion("open your eyes, look at the sky");
        gn.setIdGenero(2);
        canciont.setGenero(gn);

        canciont = canciond.actualizar(canciont);
        System.out.println("**********************************************");
        this.obtenerTodoCancion();

        return true;
    }

    public boolean borrarCancion() throws SQLException {
        canciond = new CancionDao();
        canciont = new Cancion();
        gn = new Genero();

        canciont.setNombreCancion("Dispossesion");
        canciont.setDuracion(126);
        canciont.setletraCancion("i can live this dream");
        gn.setIdGenero(3);
        canciont.setGenero(gn);

        canciont = canciond.crearCancion(canciont);
        this.obtenerTodoCancion();

        canciont = canciond.borrar(canciont);
        System.out.println("**********************************************");
        this.obtenerTodoCancion();

        return true;
    }

}
