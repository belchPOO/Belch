/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package belch.tstt;

import co.com.belch.dao.ArtistaDao;
import co.com.belch.ent.Artista;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ESTUDIANTE2302T
 */
public class ArtistaTest {

    private ArtistaDao artistad;
    private Artista artistat;

    public boolean crearArtista() throws SQLException {

        artistad = new ArtistaDao();

        artistat = new Artista();

        artistat.setNombreArtista("STFP");

        artistat = artistad.crearArtista(artistat);
        if (artistat.getIdArtista() == null) {
            return false;
        } else {
            System.out.println("Artista creado: " + artistat.getNombreArtista());
            return true;
        }

    }

    public boolean consultarArtista() throws SQLException {

        artistad = new ArtistaDao();

        artistat = new Artista();
        artistat.setNombreArtista("STFP");

        List<Artista> lArtista = new ArrayList<Artista>();

        lArtista = artistad.consultar(artistat);

        for (Artista tTemp : lArtista) {
            System.out.println("Nombre Artista: " + tTemp.getNombreArtista());
            System.out.println("-------------------------------------------");
        }

        return true;

    }

    public boolean obtenerTodoArtista() throws SQLException {
        artistad = new ArtistaDao();

        List<Artista> lArtista = new ArrayList<Artista>();

        lArtista = artistad.obtenerTodo();

        for (Artista tTemp : lArtista) {
            System.out.println("Nombre Todo Artista: " + tTemp.getNombreArtista());
            System.out.println("--------------------------------------");

        }
        return true;
    }

    public boolean actualizarArtista() throws SQLException {

        artistad = new ArtistaDao();
        artistat = new Artista();

        artistat.setNombreArtista("TCWCU");
        artistat = artistad.crearArtista(artistat);
        this.obtenerTodoArtista();

        artistat.setNombreArtista("LFLT");
        artistat = artistad.actualizar(artistat);
        System.out.println("*******************************************");
        this.obtenerTodoArtista();

        return true;

    }

    public boolean borrarArtista() throws SQLException {
        artistad = new ArtistaDao();

        artistat = new Artista();

        artistat.setNombreArtista("TGI");
        artistat = artistad.crearArtista(artistat);
        this.obtenerTodoArtista();

        artistat = artistad.borrar(artistat);
        System.out.println("**********************************");
        this.obtenerTodoArtista();

        return true;
    }
}
