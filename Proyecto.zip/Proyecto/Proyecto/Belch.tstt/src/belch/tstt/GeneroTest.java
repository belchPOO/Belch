/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package belch.tstt;

import co.com.belch.dao.GeneroDao;
import co.com.belch.ent.Genero;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ESTUDIANTE1201T
 */
public class GeneroTest {

    private GeneroDao generod;
    private Genero generot;

    public boolean crearGenero() throws SQLException {
        generod = new GeneroDao();
        generot = new Genero();
        
        generot.setNombreGenero("Hardcore");
        generot = generod.crearGenero(generot);
        
        if (generot.getIdGenero() == null) {
            return false;
        } else {
            System.out.println("Genero creado: " + generot.getNombreGenero());
            return true;
        }

    }

    public boolean consultarGenero() throws SQLException {
        generod = new GeneroDao();
        generot = new Genero();

        generot.setNombreGenero("Hardcore");

        List<Genero> lGenero = new ArrayList<Genero>();

        lGenero = generod.consultar(generot);

        for (Genero gTemp : lGenero) {
            System.out.println("Nombre Genero: " + gTemp.getNombreGenero());
            System.out.println("-----------------------------------------");
        }

        return true;
    }

    public boolean obtenerTodoGenero() throws SQLException {
        generod = new GeneroDao();

        List<Genero> lGenero = new ArrayList<Genero>();

        lGenero = generod.obtenerTodo();

        for (Genero gTemp : lGenero) {
            System.out.println("Nombre Todo Genero: " + gTemp.getNombreGenero());
            System.out.println("----------------------------------------------");
        }
        return true;
    }

    public boolean actualizarGenero() throws SQLException {
        generod = new GeneroDao();
        generot = new Genero();

        generot.setNombreGenero("Pop Punk");
        generot = generod.crearGenero(generot);
        this.obtenerTodoGenero();

        generot.setNombreGenero("Punk Rock");
        generot = generod.actualizar(generot);
        System.out.println("*************************************************");
        this.obtenerTodoGenero();

        
            return true;
        
    }

    public boolean borrarGenero() throws SQLException {
        generod = new GeneroDao();
        generot = new Genero();

        generot.setNombreGenero("Melodic Hardcore");
        generot = generod.crearGenero(generot);
        this.obtenerTodoGenero();

        generot = generod.borrar(generot);
        System.out.println("*************************************************");
        this.obtenerTodoGenero();

        return true;
    }

}
