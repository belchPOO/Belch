
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package belch.tstt;

import co.com.belch.dao.UsuarioDao;
import co.com.belch.ent.Usuario;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ESTEBAN
 */
public class UsuarioTest {

    private UsuarioDao usuariod;
    private Usuario usuariot = new Usuario();

    public boolean crearUsuario() throws SQLException {
        usuariod = new UsuarioDao();

        usuariot.setNickname("xsandritax");
        usuariot.setContraseña("1234");
        usuariot.setCorreo("sandrita@gmail.com");

        usuariot = usuariod.crearUsuario(usuariot);
        if (usuariot.getIdUsuario() == null) {
            return false;
        } else {
            System.out.println("Usuario creado: " + usuariot.getNickname());
            System.out.println("Contraseña creada: " + usuariot.getContraseña());
            System.out.println("Correo: " + usuariot.getCorreo());

            return true;
        }

    }

    public boolean consultarUsuario() throws SQLException {

        usuariod = new UsuarioDao();

        usuariot = usuariod.consultarUsuario(usuariot);

        if (usuariot.getIdUsuario() == null) {
            return false;
        } else {
            System.out.println("Usuario: " + usuariot.getNickname());
            System.out.println("Contraseña: " + usuariot.getContraseña());
            System.out.println("Correo: " + usuariot.getCorreo());

            return true;
        }

    }

    public boolean obtenerTodoUsuario() throws SQLException {
        usuariod = new UsuarioDao();

        List<Usuario> lUsuario = new ArrayList<Usuario>();

        lUsuario = usuariod.obtenerTodo();

        for (Usuario uTemp : lUsuario) {
            System.out.println("Todo nickname: " + uTemp.getNickname());
            System.out.println("--------------------------------------------");
        }
        return true;
    }

    public boolean actualizarUsuario() throws SQLException {
        usuariod = new UsuarioDao();
        usuariot = new Usuario();

        usuariot.setNickname("abcdesteban");
        usuariot.setContraseña("mimama");
        usuariot.setCorreo("esteban@gmail.com");

        usuariot = usuariod.crearUsuario(usuariot);
        this.obtenerTodoUsuario();

        usuariot.setNickname("abcdaniela");
        usuariot.setContraseña("mipapa");
        usuariot.setCorreo("daniela@gmail.com");

        usuariot = usuariod.actualizar(usuariot);
        System.out.println("**********************************************");
        this.obtenerTodoUsuario();

        return true;
    }

    public boolean borrarUsuario() throws SQLException {

        usuariod = new UsuarioDao();
        usuariot = new Usuario();

        usuariot.setNickname("Lasmilcum");
        usuariot.setContraseña("147");
        usuariot.setCorreo("lasmil@gmail.com");

        usuariot = usuariod.crearUsuario(usuariot);
        this.obtenerTodoUsuario();

        usuariot = usuariod.borrar(usuariot);
        System.out.println("**********************************************");
        this.obtenerTodoUsuario();

        return true;
    }

}
