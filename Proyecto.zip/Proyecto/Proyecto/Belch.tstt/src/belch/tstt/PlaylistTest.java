/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package belch.tstt;

import co.com.belch.dao.PlayListDao;
import co.com.belch.ent.PlayList;
import java.sql.SQLException;

/**
 *
 * @author ESTEBAN
 */
public class PlaylistTest {

    private PlayListDao playlistd;
    private PlayList playlistt;

    public boolean crearPlaylist() throws SQLException {
        playlistd = new PlayListDao();
        playlistt =  new PlayList();
        
        
        return true;
    }

    public boolean consultarPlaylist() throws SQLException {
        return true;
    }

    public boolean obtenerTodoPlaylist() throws SQLException {
        return true;
    }

    public boolean actualizarPlaylist() throws SQLException {
        return true;
    }

    public boolean borrarPlaylist() throws SQLException {
        return true;
    }

}
