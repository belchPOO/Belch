/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package belch.tstt;

import co.com.belch.dao.AlbumDao;
import co.com.belch.ent.Album;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ESTUDIANTE2302T
 */
public class AlbumTest {

    private AlbumDao albumd;
    private Album albumt;

    public boolean crearAlbum() throws SQLException {

        albumd = new AlbumDao();

        albumt = new Album();

        albumt.setNombreAlbum("Snap");

        albumt = albumd.crearAlbum(albumt);
        if (albumt.getIdAlbum() == null) {
            return false;
        } else {
            System.out.println("Album creado: " + albumt.getNombreAlbum());
            return true;
        }

    }

    public boolean consultarAlbum() throws SQLException {

        albumd = new AlbumDao();

        albumt = new Album();
        albumt.setNombreAlbum("Snap");

        List<Album> lAlbum = new ArrayList<Album>();

        lAlbum = albumd.consultar(albumt);

        for (Album aTemp : lAlbum) {
            System.out.println("Nombre album: " + aTemp.getNombreAlbum());
            System.out.println("---------------------------------------");

        }
        
        return true;
    }

    public boolean obtenerTodoAlbum() throws SQLException {

        albumd = new AlbumDao();

        List<Album> lAlbum = new ArrayList<Album>();

        lAlbum = albumd.obtenerTodo();

        for (Album aTemp : lAlbum) {
            System.out.println("Nombre Todo album: " + aTemp.getNombreAlbum());
            System.out.println("------------------------------------");

        }
        return true;
    }

    public boolean actualizarAlbum() throws SQLException {

        albumd = new AlbumDao();

        albumt = new Album();

        albumt.setNombreAlbum("La tetica");

        albumt = albumd.crearAlbum(albumt);
        this.obtenerTodoAlbum();

        albumt.setNombreAlbum("La pucheca");
        albumt = albumd.actualizar(albumt);
        System.out.println("*****************************");
        this.obtenerTodoAlbum();

        if (albumt.getIdAlbum() == null) {
            return false;
        } else {
            return true;
        }

    }

    public boolean borrarAlbum() throws SQLException {

        albumd = new AlbumDao();
        albumt = new Album();

        albumt.setNombreAlbum("Mimamaestabrava");
        albumt = albumd.crearAlbum(albumt);
        this.obtenerTodoAlbum();
       
        albumt = albumd.borrar(albumt);
        System.out.println("******************************");
        this.obtenerTodoAlbum();

        return true;
    }

}
