/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package belch.tstt;

import co.com.belch.dal.Conexion;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ESTUDIANTE2302T
 */
public class BelchTstt {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Conexion c = new Conexion();

        try {
            c.conectar();
        } catch (SQLException ex) {
            Logger.getLogger(BelchTstt.class.getName()).log(Level.SEVERE, null, ex);
        }
        //------------------------TEST ALBUM-----------------------------------//
        AlbumTest albumt = new AlbumTest();

        try {
            System.out.println("-----------------TEST ALBUM------------------");

            albumt.crearAlbum();
            System.out.println("//-----------------------------------------//");

            albumt.consultarAlbum();
            System.out.println("//-----------------------------------------//");

            albumt.obtenerTodoAlbum();
            System.out.println("//-----------------------------------------//");

            albumt.actualizarAlbum();
            System.out.println("//-----------------------------------------//");

            albumt.borrarAlbum();

        } catch (SQLException ex) {
            Logger.getLogger(BelchTstt.class.getName()).log(Level.SEVERE, null, ex);
        }
        //------------------------TEST ARTISTA---------------------------------//

        ArtistaTest artistat = new ArtistaTest();

        try {
            System.out.println("-----------------TEST ARTISTA----------------");

            artistat.crearArtista();
            System.out.println("//-----------------------------------------//");

            artistat.consultarArtista();
            System.out.println("//-----------------------------------------//");

            artistat.obtenerTodoArtista();
            System.out.println("//-----------------------------------------//");

            artistat.actualizarArtista();
            System.out.println("//-----------------------------------------//");

            artistat.borrarArtista();

        } catch (SQLException ex) {
            Logger.getLogger(BelchTstt.class.getName()).log(Level.SEVERE, null, ex);
        }
        //----------------------------------TEST CANCION-----------------------//
         /*CancionTest canciont = new CancionTest();

        try {
            System.out.println("-----------------TEST CANCION----------------");

            canciont.crearCancion();
            System.out.println("//-----------------------------------------//");

            canciont.consultarCancion();
            System.out.println("//----------------------------------------//");

            canciont.obtenerTodoCancion();
            System.out.println("//-----------------------------------------//");

            canciont.actualizarCancion();
            System.out.println("//-----------------------------------------//");

            canciont.borrarCancion();

        } catch (SQLException ex) {
            Logger.getLogger(BelchTstt.class.getName()).log(Level.SEVERE, null, ex);

        }*/
        //-----------------------------TEST GENERO-----------------------------//

        GeneroTest generot = new GeneroTest();

        try {
            System.out.println("-------------------TEST GENERO---------------");

            generot.crearGenero();
            System.out.println("//------------------------------------------//");

            generot.consultarGenero();
            System.out.println("//----------------------------------------//");

            generot.obtenerTodoGenero();
            System.out.println("//----------------------------------------//");

            generot.actualizarGenero();
            System.out.println("//----------------------------------------//");

            generot.borrarGenero();

        } catch (SQLException ex) {
            Logger.getLogger(BelchTstt.class.getName()).log(Level.SEVERE, null, ex);

        }
        //-------------------------TEST PLAYLIST------------------------------//
        /*PlaylistTest playlistt = new PlaylistTest();

        try {
            System.out.println("----------------TEST PLAYLIST-------------------");

            playlistt.crearPlaylist();
            System.out.println("//----------------------------------------//");

            playlistt.consultarPlaylist();
            System.out.println("//----------------------------------------//");

            playlistt.obtenerTodoPlaylist();
            System.out.println("//----------------------------------------//");

            playlistt.actualizarPlaylist();
            System.out.println("//----------------------------------------//");

            playlistt.borrarPlaylist();

        } catch (SQLException ex) {
            Logger.getLogger(BelchTstt.class.getName()).log(Level.SEVERE, null, ex);
        }*/
        //------------------------TEST USUARIO--------------------------------//
        UsuarioTest usuariot = new UsuarioTest();

        try {
            System.out.println("------------------TEST USUARIO------------------");

            usuariot.crearUsuario();
            System.out.println("//----------------------------------------//");

            usuariot.consultarUsuario();
            System.out.println("//----------------------------------------//");

            usuariot.obtenerTodoUsuario();
            System.out.println("//----------------------------------------//");

            usuariot.actualizarUsuario();
            System.out.println("//----------------------------------------//");

            usuariot.borrarUsuario();
        } catch (SQLException ex) {
            Logger.getLogger(BelchTstt.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
