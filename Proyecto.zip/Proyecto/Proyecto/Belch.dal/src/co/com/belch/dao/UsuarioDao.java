/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.belch.dao;

import co.com.belch.dal.Conexion;
import co.com.belch.ent.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ESTUDIANTE2302T
 */
public class UsuarioDao {

    private Usuario usuario;
    private Connection link;
    private PreparedStatement stmn;

    public UsuarioDao() throws SQLException {
        Conexion c = new Conexion();
        this.link = c.conectar();
    }

    public Usuario crearUsuario(Usuario usu) throws SQLException {

        String sql = "INSERT INTO Usuario( nombreUsuario, contraseña, correo) values (?,?,?)";

        stmn = this.link.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

        stmn.setString(1, usu.getNickname());
        stmn.setString(2, usu.getContraseña());
        stmn.setString(3, usu.getCorreo());

        stmn.execute();

        ResultSet rs = stmn.getGeneratedKeys();
        rs.next();
        System.out.println(rs.getInt(1));

        usu.setIdUsuario(rs.getInt(1));

        return usu;
    }

    public Usuario consultarUsuario(Usuario usu) throws SQLException {

        this.stmn = link.prepareStatement("SELECT * FROM Usuario Where id_usuario = ?");

        stmn.setInt(1, usu.getIdUsuario());

        ResultSet rs = stmn.executeQuery();
        if (rs.next()) {
            usu.setIdUsuario(rs.getInt(1));
            usu.setNickname(rs.getString("nombreUsuario"));
            usu.setContraseña(rs.getString("contraseña"));
            usu.setCorreo(rs.getString("correo"));
        } else {
            return null;
        }
        return usu;

    }

    public List<Usuario> obtenerTodo() throws SQLException {
        List<Usuario> listaUsuario = new ArrayList<Usuario>();
        Usuario u;

        this.stmn = link.prepareStatement("SELECT * FROM Usuario");
        ResultSet rs = stmn.executeQuery();

        while (rs.next()) {
            u = new Usuario();
            u.setNickname(rs.getString("nombreUsuario"));
            listaUsuario.add(u);

        }
        return listaUsuario;
    }

    public Usuario actualizar(Usuario usu) throws SQLException {

        stmn = link.prepareStatement("UPDATE Usuario SET nombreUsuario = ?, contraseña = ?, correo = ? WHERE id_usuario = ? ");
        stmn.setString(1, usu.getNickname());
        stmn.setString(2, usu.getContraseña());
        stmn.setString(3, usu.getCorreo());
        stmn.setInt(4, usu.getIdUsuario());

        stmn.executeUpdate();

        return usu;
    }

    public Usuario borrar(Usuario usu) throws SQLException {

        stmn = link.prepareStatement("DELETE FROM Usuario WHERE id_usuario = ? ");

        stmn.setInt(1, usu.getIdUsuario());

        stmn.execute();

        return usu;

    }

}
