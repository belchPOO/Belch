/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.belch.dao;

import co.com.belch.dal.Conexion;
import co.com.belch.ent.Artista;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ESTUDIANTE2302T
 */
public class ArtistaDao {

    private Artista artista;
    private Connection link;
    private PreparedStatement stmn;

    public ArtistaDao() throws SQLException {
        Conexion c = new Conexion();
        this.link = c.conectar();

    }

    public Artista crearArtista(Artista art) throws SQLException {

        String sql = "INSERT INTO Artista(nombre) values (?)";

        stmn = this.link.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        stmn.setString(1, art.getNombreArtista());
        stmn.execute();
//
        ResultSet rs = stmn.getGeneratedKeys();
        rs.next();
        System.out.println(rs.getInt(1));

        art.setIdArtista(rs.getInt(1));

        return art;
    }

    public List<Artista> consultar(Artista art) throws SQLException {

        List<Artista> listaArtista = new ArrayList<Artista>();
        Artista t;

        this.stmn = link.prepareStatement("SELECT * FROM Artista where nombre= ?");
        stmn.setString(1, art.getNombreArtista());
        ResultSet rs = stmn.executeQuery();
        while (rs.next()) {
            t = new Artista();
            t.setIdArtista(rs.getInt("id_artista"));
            t.setNombreArtista(rs.getString("nombre"));
            listaArtista.add(t);
        }
        return listaArtista;

    }

    public List<Artista> obtenerTodo() throws SQLException {

        List<Artista> listaArtista = new ArrayList<Artista>();
        Artista t;

        this.stmn = link.prepareStatement("SELECT * FROM Artista");
        ResultSet rs = stmn.executeQuery();

        while (rs.next()) {
            t = new Artista();
            t.setNombreArtista(rs.getString("nombre"));
            listaArtista.add(t);
        }
        return listaArtista;
    }

    public Artista actualizar(Artista art) throws SQLException {

        stmn = link.prepareStatement("UPDATE artista SET nombre = ? WHERE id_artista = ?");

        stmn.setString(1, art.getNombreArtista());
        stmn.setInt(2, art.getIdArtista());

        stmn.executeUpdate();

        return art;
    }

    public Artista borrar(Artista art) throws SQLException {

        stmn = link.prepareStatement("DELETE FROM artista where id_artista = ?");

        stmn.setInt(1, art.getIdArtista());

        stmn.execute();

        return art;

    }
}
