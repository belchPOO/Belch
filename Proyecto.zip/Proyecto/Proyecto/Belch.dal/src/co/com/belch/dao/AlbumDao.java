/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.belch.dao;

import co.com.belch.dal.Conexion;
import co.com.belch.ent.Album;
import co.com.belch.ent.Cancion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ESTUDIANTE2302T
 */
public class AlbumDao {

    private Album album;
    private Connection link;
    private PreparedStatement stmn;

    public AlbumDao() throws SQLException {
        Conexion c = new Conexion();
        this.link = c.conectar();
    }

    public Album crearAlbum(Album alb) throws SQLException {

        String sql = "insert into Album(nombre) values (?)";

        stmn = this.link.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

        stmn.setString(1, alb.getNombreAlbum());
        stmn.execute();

        ResultSet rs = stmn.getGeneratedKeys();
        rs.next();
        //System.out.println(rs.getInt(1));//-1

        alb.setIdAlbum(rs.getInt(1));

        return alb;

    }

    public Album agregarCancion(Album alb, Cancion can) throws SQLException {

        CancionDao cd = new CancionDao();
        cd.crearCancion(can);

        this.consultar(alb);

        return alb;

        //TODO: Terminar
    }

    public List<Album> consultar(Album alb) throws SQLException {//Cambiar Nombre

        List<Album> listaAlbum = new ArrayList<Album>();
        Album a;

        this.stmn = link.prepareStatement("select * from album where nombre=?");
        stmn.setString(1, alb.getNombreAlbum());
        ResultSet rs = stmn.executeQuery();
        while (rs.next()) {
            a = new Album();
            a.setIdAlbum(rs.getInt("id_album"));
            a.setNombreAlbum(rs.getString("nombre"));
            listaAlbum.add(a);
        }

        return listaAlbum;

    }

    public List<Album> obtenerTodo() throws SQLException {

        List<Album> listaAlbum = new ArrayList<Album>();
        Album a;

        this.stmn = link.prepareStatement("select * from album");
        ResultSet rs = stmn.executeQuery();

        while (rs.next()) {
            a = new Album();
            a.setNombreAlbum(rs.getString("nombre"));
            listaAlbum.add(a);
        }

        return listaAlbum;

    }

    public Album actualizar(Album alb) throws SQLException {

        stmn = link.prepareStatement("UPDATE album SET nombre = ? WHERE id_album = ?");

        stmn.setString(1, alb.getNombreAlbum());
        stmn.setInt(2, alb.getIdAlbum());

        stmn.executeUpdate();

        return alb;

    }

    public Album borrar(Album alb) throws SQLException {

        stmn = link.prepareStatement("DELETE FROM album WHERE id_album = ?");

        stmn.setInt(1, alb.getIdAlbum());

        //stmn.execute();
        stmn.executeUpdate();

        return alb;
    }

}
