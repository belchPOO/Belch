/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.belch.dao;

import co.com.belch.dal.Conexion;
import co.com.belch.ent.Genero;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ESTUDIANTE2302T
 */
public class GeneroDao {

    private Genero genero;
    private Connection link;
    private PreparedStatement stmn;

    public GeneroDao() throws SQLException {
        Conexion c = new Conexion();
        this.link = c.conectar();
    }

    public Genero crearGenero(Genero gen) throws SQLException {

        String sql = "INSERT INTO Genero(nombre) values (?)";

        stmn = this.link.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

        stmn.setString(1, gen.getNombreGenero());
        stmn.execute();

        ResultSet rs = stmn.getGeneratedKeys();
        rs.next();
        System.out.println(rs.getInt(1));

        gen.setIdGenero(rs.getInt(1));

        return gen;
    }

    public List<Genero> consultar(Genero gen) throws SQLException {

        List<Genero> listaGenero = new ArrayList<Genero>();
        Genero g;

        this.stmn = link.prepareStatement("SELECT * FROM Genero where nombre= ?");
        stmn.setString(1, gen.getNombreGenero());
        ResultSet rs = stmn.executeQuery();
        while (rs.next()) {
            g = new Genero();
            g.setIdGenero(rs.getInt("id_genero"));
            g.setNombreGenero(rs.getString("nombre"));
            listaGenero.add(g);
        }
        return listaGenero;
    }

    public Genero consultarXId(Integer idG) throws SQLException {

        Genero g;

        this.stmn = link.prepareStatement("SELECT * FROM Genero where id_genero= ?");
        stmn.setInt(1, idG);
        ResultSet rs = stmn.executeQuery();
        rs.next();
        g = new Genero();
        g.setIdGenero(rs.getInt("id_genero"));
        g.setNombreGenero(rs.getString("nombre"));        
        return g;
    }

    public List<Genero> obtenerTodo() throws SQLException {

        List<Genero> listaGenero = new ArrayList<Genero>();
        Genero g;

        this.stmn = link.prepareStatement("SELECT * FROM Genero");
        ResultSet rs = stmn.executeQuery();

        while (rs.next()) {
            g = new Genero();
            g.setNombreGenero(rs.getString("nombre"));
            listaGenero.add(g);
        }
        return listaGenero;
    }

    public Genero actualizar(Genero gen) throws SQLException {

        stmn = link.prepareStatement("UPDATE Genero SET nombre = ? WHERE id_genero= ? ");

        stmn.setString(1, gen.getNombreGenero());
        stmn.setInt(2, gen.getIdGenero());

        stmn.executeUpdate();

        return gen;
    }

    public Genero borrar(Genero gen) throws SQLException {

        stmn = link.prepareStatement("DELETE FROM Genero WHERE id_genero = ?");

        stmn.setInt(1, gen.getIdGenero());

        stmn.execute();

        return gen;

    }

}
