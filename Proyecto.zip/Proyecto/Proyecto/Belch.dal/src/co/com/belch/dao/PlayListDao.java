/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.belch.dao;

import co.com.belch.dal.Conexion;
import co.com.belch.ent.Cancion;
import co.com.belch.ent.PlayList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author ESTUDIANTE2302T
 */
public class PlayListDao {

    private PlayList playlist;
    private Connection link;
    private PreparedStatement stmn;

    public PlayListDao() throws SQLException {
        Conexion c = new Conexion();
        this.link = c.conectar();

    }

    public PlayList registrar(PlayList play) throws SQLException {

        String sql = "INSERT INTO PlayList(nombre_playlist, capacidad, privacidad, id_usuario) values (?,?,?,?,?)";

        stmn = this.link.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        stmn.setString(1, play.getNombrePlay());
        stmn.setString(3, play.getCapacidad());
        stmn.setString(4, play.getPrivacidad());
        stmn.setInt(5, play.getIdUsuario().getIdUsuario());

        stmn.execute();

        ResultSet rs = stmn.getGeneratedKeys();
        rs.next();
        System.out.println(rs.getInt(1));

        play.setidPlaylist(rs.getInt(1));

        return play;
    }
    public Cancion agregarCancion(Cancion can ) throws SQLException{
    String sql = "INSERT INTO cancion_x_playlist (id_cancion) values(?)";
    
        return can;
    }

    public PlayList consultar(PlayList play) throws SQLException {

        this.stmn = link.prepareStatement("SELECT * FROM playlist Where id_playlist = ?");

        stmn.setInt(1, play.getidPlaylist());

        ResultSet rs = stmn.executeQuery();
        if (rs.next()) {
            play.setidPlaylist(rs.getInt(1));
            play.setNombrePlay(rs.getString("nombre_playlist"));
        } else {
            return null;
        }

        return play;
    }

    public PlayList actualizar(PlayList play) throws SQLException {

        stmn = link.prepareStatement("UPDATE PlayList " + "SET idCancion = ?," + "nombre = ?," + "WHERE idPlaylist = " + play.getidPlaylist());

        //stmn.setString(1, play.getLista().toString());
        stmn.setString(2, play.getNombrePlay());
        stmn.setString(3, play.getidPlaylist().toString());
        stmn.executeUpdate();

        return play;
    }

    public PlayList borrar(PlayList play) throws SQLException {

        stmn = link.prepareStatement("DELETE * FROM PlayList WHERE idPlaylist = " + play.getidPlaylist());

        //stmn.setString(1, play.getLista().toString());
        stmn.setString(2, play.getNombrePlay());
        stmn.setString(3, play.getidPlaylist().toString());
        stmn.execute();

        return play;

    }

}
