/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.belch.dao;

import co.com.belch.dal.Conexion;
import co.com.belch.ent.Cancion;
import co.com.belch.ent.Genero;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ESTUDIANTE2302T
 */
public class CancionDao {

    private Cancion cancion;
    private Connection link;
    private PreparedStatement stmn;

    public CancionDao() throws SQLException {
        Conexion c = new Conexion();
        this.link = c.conectar();

    }

    public Cancion crearCancion(Cancion can) throws SQLException {

        String sql = "INSERT INTO Cancion( nombre, tiempo_duracion, letra_cancion, id_genero) values (?,?,?,?)";

        stmn = this.link.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        stmn.setString(1, can.getNombreCancion());
        stmn.setInt(2, can.getDuracion());
        stmn.setString(3, can.getletraCancion());
        stmn.setInt(4, can.getGenero().getIdGenero());
        stmn.execute();

        ResultSet rs = stmn.getGeneratedKeys();
        rs.next();
        System.out.println(rs.getInt(1));

        can.setIdCancion(rs.getInt(1));

        return can;
    }

    public List<Cancion> consultar(Cancion can) throws SQLException {

        List<Cancion> listaCancion = new ArrayList<Cancion>();
        Cancion c;
        Genero gn = new Genero();
        GeneroDao dao = new GeneroDao();

        this.stmn = link.prepareStatement("SELECT * FROM Cancion where nombre= ?");
        stmn.setString(1, can.getNombreCancion());
        stmn.setInt(2, can.getDuracion());
        stmn.setString(3, can.getletraCancion());
        stmn.setInt(4, can.getGenero().getIdGenero());
        ResultSet rs = stmn.executeQuery();

        while (rs.next()) {
            c = new Cancion();
            c.setIdCancion(rs.getInt("id_cancion"));
            c.setNombreCancion(rs.getString("nombre"));
            c.setDuracion(rs.getInt("tiempo_duracion"));
            c.setletraCancion(rs.getString("letra_cancion"));

            c.setGenero(dao.consultarXId(rs.getInt("id_genero")));
            listaCancion.add(c);
        }

        return listaCancion;

    }

    public List<Cancion> obtenerTodo() throws SQLException {
        List<Cancion> listaCancion = new ArrayList<Cancion>();
        Cancion c;

        this.stmn = link.prepareStatement("SELECT * FROM Cancion");
        ResultSet rs = stmn.executeQuery();

        while (rs.next()) {
            c = new Cancion();
            c.setNombreCancion("nombre");
            listaCancion.add(c);
        }

        return listaCancion;
    }

    public Cancion actualizar(Cancion can) throws SQLException {

        stmn = link.prepareStatement("UPDATE Cancion SET nombre = ?, tiempo_duracion = ?, letra_cancion = ?  Where id_cancion = ?");

        stmn.setString(1, can.getNombreCancion());
        stmn.setInt(2, can.getDuracion());
        stmn.setString(3, can.getletraCancion());
        stmn.setInt(4, can.getIdCancion());

        stmn.executeUpdate();

        return can;
    }

    public Cancion borrar(Cancion can) throws SQLException {

        stmn = link.prepareStatement("DELETE FROM cancion WHERE id_cancion = ?");

        stmn.setInt(1, can.getIdCancion());

        stmn.execute();

        return can;

    }

}
