/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.belch.dal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ESTUDIANTE2302T
 */
public class Conexion {

    private static String URL = "jdbc:mysql://localhost:3306/";
    private static String DATA_BASE = "reproductor";
    private static String USER = "root";
    private static String PASSWORD = "";
    private Connection link = null;

    public Connection conectar() throws SQLException {
        try {
            Class.forName("com.mysql.jdbc.Driver");

        } catch (ClassNotFoundException e) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, e);
        }
        String path = URL + DATA_BASE;
        link = DriverManager.getConnection(path, USER, PASSWORD);

        return link;
 
    }

    private void desconectar() throws SQLException {

        link.close();

    }

}
