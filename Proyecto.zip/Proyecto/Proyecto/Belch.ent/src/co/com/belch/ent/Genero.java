/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.belch.ent;

/**
 *
 * @author ESTUDIANTE2302T
 */
public class Genero {

    private Integer idGenero;
    private String nombre;

    public void setIdGenero(Integer gene) {

        this.idGenero = gene;

    }

    public Integer getIdGenero() {

        return this.idGenero;

    }

    public void setNombreGenero(String name) {

        this.nombre = name;

    }

    public String getNombreGenero() {

        return this.nombre;
    }
}
