/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.belch.ent;

import java.sql.Date;

/**
 *
 * @author ESTUDIANTE2302T
 */
public class Usuario {

    private Integer idUsuario;
    private String Nickname = "Usuario";
    private String contraseña = "Contraseña";
    private String Correo;

//--------------------Metodo Id_Usuario-----------------// 
    public void setIdUsuario(Integer Usuario) {

        this.idUsuario = Usuario;

    }

    public Integer getIdUsuario() {

        return this.idUsuario;

    }
//--------------------Metodo Nickname-----------------// 

    public void setNickname(String name) {

        this.Nickname = name;

    }

    public String getNickname() {

        return this.Nickname;

    }
    //--------------------Metodo Contraseña-----------------// 

    public void setContraseña(String pass) {

        this.contraseña = pass;

    }

    public String getContraseña() {

        return this.contraseña;

    }

    //--------------------Metodo Contraseña-----------------// 
    public void setCorreo(String email) {

        this.Correo = email;

    }

    public String getCorreo() {

        return this.Correo;

    }

}
