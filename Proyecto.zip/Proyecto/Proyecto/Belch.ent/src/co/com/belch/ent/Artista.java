/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.belch.ent;

/**
 *
 * @author ESTUDIANTE2302T
 */
public class Artista {

    private Integer idArtista;
    private String nombreArtista;

    public void setIdArtista(Integer artis) {

        this.idArtista = artis;

    }

    public Integer getIdArtista() {

        return this.idArtista;

    }

    public void setNombreArtista(String nombre) {

        this.nombreArtista = nombre;

    }

    public String getNombreArtista() {

        return this.nombreArtista;

    }

}
