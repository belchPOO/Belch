/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.belch.ent;

import java.util.ArrayList;

/**
 *
 * @author ESTUDIANTE2302T
 */
public class Album {

    
    private Integer idAlbum;
    private String nombreAlbum;
    



    public void setIdAlbum(Integer album) {

        this.idAlbum = album;

    }

    public Integer getIdAlbum() {

        return this.idAlbum;
    }

    public void setNombreAlbum(String nomalbum) {

        this.nombreAlbum = nomalbum;

    }

    public String getNombreAlbum() {

        return this.nombreAlbum;
    }
}
