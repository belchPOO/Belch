/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.belch.ent;

import java.util.ArrayList;

/**
 *
 * @author ESTUDIANTE2302T
 */
public class PlayList {

    private Integer idPlaylist;
    private ArrayList<Cancion> lista = new ArrayList<Cancion>();
    private String nombre;
    private String capacidad;
    private String privacidad;
    private Usuario idUsuario;

    public void setidPlaylist(Integer play) {

        this.idPlaylist = play;
    }

    public Integer getidPlaylist() {

        return this.idPlaylist;
    }

    public void setCancion(ArrayList<Cancion> ca) {

        this.lista = ca;
    }

    public ArrayList<Cancion> getCancion() {

        return this.lista;
    }

    public void setNombrePlay(String play) {
        this.nombre = play;
    }

    public String getNombrePlay() {
        return this.nombre;
    }

    public void setCapacidad(String cap) {
        this.capacidad = cap;
    }

    public String getCapacidad() {
        return this.capacidad;
    }

    public void setPrivacidad(String pri) {
        this.privacidad = pri;
    }

    public String getPrivacidad() {
        return this.privacidad;
    }

    public void setIdUsuario(Usuario usu) {
        this.idUsuario = usu;
    }

    public Usuario getIdUsuario() {
        return this.idUsuario;
    }

}
