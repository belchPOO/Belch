/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.belch.ent;

/**
 *
 * @author ESTUDIANTE2302T
 */
public class Cancion {

    private Integer idCancion;
    private String nombreCancion;
    private Integer tiempoDuracion;
    private String letraCancion;
    private Genero genero;

    public void setIdCancion(Integer idca) {
        this.idCancion = idca;

    }

    public Integer getIdCancion() {
        return this.idCancion;

    }

    public void setNombreCancion(String nombrecancion) {
        this.nombreCancion = nombrecancion;

    }

    public String getNombreCancion() {
        return this.nombreCancion;

    }

    public void setDuracion(Integer dura) {
        this.tiempoDuracion = dura;

    }

    public Integer getDuracion() {
        return this.tiempoDuracion;

    }

    public void setletraCancion(String letra) {
        this.letraCancion = letra;

    }

    public String getletraCancion() {
        return this.letraCancion;
    }

    public void setGenero(Genero genero) {
        this.genero = genero;

    }

    public Genero getGenero() {
        return this.genero;

    }

}
